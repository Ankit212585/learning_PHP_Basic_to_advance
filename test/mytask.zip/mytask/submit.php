<?php
echo "my origin :-" . $_GET["origin"];
echo "<br/>";
echo "my Destination :-" . $_GET["Destination"];
echo "<br/>";
echo "our date :-" . $_GET["Depart_Date"];
echo "<br/>";
echo "my email :-" . $_GET["email"];
echo "<br/>";
echo "passegers list :-" . $_GET["Passengers"];

?>





<!-- hr@callsbridge.com -->